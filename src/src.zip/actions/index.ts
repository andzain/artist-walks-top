import { defineAction } from "astro:actions";
import { z } from "astro:schema";
import { prisma } from "../lib/prisma";

export const server = {
  createBooking: defineAction({
    accept: "json",
    input: z.object({
      experienceSlug: z.string(),
      name: z.string(),
      email: z.string().email(),
    }),
    handler: async (input) => {
      const newBooking = await prisma.booking.create({
        data: {
          experienceSlug: input.experienceSlug,
          name: input.name,
          email: input.email,
          walk: {
            connect: {
              slug: input.experienceSlug,
            },
          },
        },
      });
      return newBooking;
    },
  }),
};
