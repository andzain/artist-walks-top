<script lang="ts">
  import { actions } from "astro:actions";

  export let experienceSlug: string;

  let name = "";
  let email = "";
  let message = "";
  let loading = false;

  async function submitBooking() {
    loading = true;
    message = "";
    const { error } = await actions.createBooking({ experienceSlug, name, email });
    if (error) {
      message = error.message;
    } else {
      message = "Booking received. Thank you!";
      name = "";
      email = "";
    }
    loading = false;
  }
</script>

<form on:submit|preventDefault={submitBooking}>
  <label>Name <input bind:value={name} required /></label>
  <label>Email <input type="email" bind:value={email} required /></label>
  <button disabled={loading}>{loading ? "Sending..." : "Book walk"}</button>
</form>

{#if message}<p>{message}</p>{/if}