import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import pg from "pg";
import "dotenv/config";

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient };

let prisma: PrismaClient;

if (globalForPrisma.prisma) {
  prisma = globalForPrisma.prisma;
} else {
  // 1. Create a native pg connection pool
  const pool = new pg.Pool({
    connectionString: process.env.DATABASE_URL,
  });

  // 2. Wrap the pool with Prisma's adapter
  const adapter = new PrismaPg(pool);

  // 3. Instantiate the client passing the adapter
  prisma = new PrismaClient({
    adapter,
    log: ["query"],
  });

  if (process.env.NODE_ENV !== "production") {
    globalForPrisma.prisma = prisma;
  }
}

export { prisma };
