---
title: "Soviet Modernism"
experienceSlug: "soviet-modernism"
+debugField: "HELLO123"

description: "Discover Yerevan's remarkable Soviet architecture through an artist's perspective."

category: "Architecture"

duration: "3 hours"

meetingPoint: "Cascade Complex"

pricing:
  group: 25
  private: 50
  fullDay: 200

languages:
  - English
  - Russian

difficulty: "Easy"

featured: true

calEvent: "modernism"

hero: "/images/experiences/soviet-modernism.webp"

gallery:
  - "/images/experiences/soviet-modernism-1.webp"
  - "/images/experiences/soviet-modernism-2.webp"

order: 1

tags:
  - Soviet Modernism
  - Architecture
  - Photography
  - Urban History
---

Explore Yerevan's unique collection of Soviet modernist buildings through the eyes of a contemporary artist.

Rather than simply identifying buildings, this experience explains the ideas behind them—how architecture reflected politics, society, technology, and everyday life in Soviet Armenia.

The walk includes iconic landmarks, hidden architectural details, and stories rarely found in guidebooks.
